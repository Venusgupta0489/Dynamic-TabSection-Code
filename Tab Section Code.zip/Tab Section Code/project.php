     <!-- Project Section Start -->
     <div class="rs-project style1 bg3 pt-100 pb-100 md-pt-70 md-pb-70">
                <div class="container">
                    <div class="sec-title text-center mb-60 md-mb-40">
                        <h2 class="title title2">
                            Completed business cases
                        </h2>
                    </div>
                    <ul class="nav nav-tabs  gridFilter mb-50 md-mb-30 text-center" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button  class="nav-link active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab"
                             aria-controls="all" aria-selected="true">All</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="businessstrategy-tab" data-bs-toggle="tab" data-bs-target="#businessstrategy" type="button" role="tab" 
                            aria-controls="businessstrategy" aria-selected="false">Business Strategy</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="financial-tab" data-bs-toggle="tab" data-bs-target="#financial" type="button" role="tab" 
                            aria-controls="financial" aria-selected="false">Financial</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" 
                            aria-controls="contact" aria-selected="false">Investment</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" 
                            aria-controls="contact" aria-selected="false">Tax Consulting</button>
                        </li> 
                        </ul>
                        <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                            <div class="row">
                            <?php foreach(get_sub_field('business_cases') as $value){ ?>
                                <div class="col-lg-4 col-md-6 mb-30 grid-item filter1">
                                    <div class="project-item">
                                        <div class="project-img">
                                            <img src="assets/images/project/style1/1.jpg" alt="images">
                                        </div>
                                        <div class="project-content"> 
                                            <div class="project-inner">
                                                <span class="category"><a href="project-single.html">Investment</a></span>
                                                <h3 class="title"><a href="project-single.html">Business planning</a></h3>
                                                <a class="p-icon" href="project-single.html"><i class="custom-icon"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <?php } ?>
                                </div>
                                
                        </div>
                        <div class="tab-pane fade" id="businessstrategy" role="tabpanel" aria-labelledby="businessstrategy-tab">
                        <div class="row">
                            <?php foreach(get_sub_field('business_cases') as $value){ 
                               if($value['category']=="businessstrategy"){ ?>
                                <div class="col-lg-4 col-md-6 mb-30 grid-item filter1">
                                    <div class="project-item">
                                        <div class="project-img">
                                            <img src="assets/images/project/style1/1.jpg" alt="images">
                                        </div>
                                        <div class="project-content"> 
                                            <div class="project-inner">
                                                <span class="category"><a href="project-single.html"><?= $value['category'] ?></a></span>
                                                <h3 class="title"><a href="project-single.html">Business planning</a></h3>
                                                <a class="p-icon" href="project-single.html"><i class="custom-icon"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <?php } } ?>
                                </div>
                        </div>
                        <div class="tab-pane fade" id="financial" role="tabpanel" aria-labelledby="financial-tab">
                            <div class="row">
                            <?php foreach(get_sub_field('business_cases') as $value){ 
                               if($value['category']=="financial"){ ?>
                                <div class="col-lg-4 col-md-6 mb-30 grid-item filter1">
                                    <div class="project-item">
                                        <div class="project-img">
                                            <img src="assets/images/project/style1/1.jpg" alt="images">
                                        </div>
                                        <div class="project-content"> 
                                            <div class="project-inner">
                                                <span class="category"><a href="project-single.html"><?= $value['category'] ?></a></span>
                                                <h3 class="title"><a href="project-single.html">Business planning</a></h3>
                                                <a class="p-icon" href="project-single.html"><i class="custom-icon"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <?php } } ?>
                                </div>
                        </div>                        
                    </div>
                </div>
            </div>
            <!-- Project Section End --> 