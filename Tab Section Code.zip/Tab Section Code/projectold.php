       <!-- Project Section Start -->
<div class="rs-project style1 bg3 pt-100 pb-100 md-pt-70 md-pb-70">
                <div class="container">
                                    <div class="sec-title text-center mb-60 md-mb-40">
                                        <h2 class="title title2">
                                        <?= get_sub_field('project_top_content')['project_heading'] ?>
                                        </h2>
                                    </div>
                                    
                                    <div class="gridFilter mb-50 md-mb-30 text-center">
                                        <button class="active" data-filter="*" id="all"><?= get_sub_field('project_top_content')['project_sub_heading_one'] ?></button>
                                        <button data-filter=".filter2" id="businessstrategy"><?= get_sub_field('project_top_content')['project_sub_heading_two'] ?></button>
                                        <button data-filter=".filter3" id="financial"><?= get_sub_field('project_top_content')['project_sub_heading_three'] ?></button>
                                        <button data-filter=".filter4" id="investment"><?= get_sub_field('project_top_content')['project_sub_heading_four'] ?></button>
                                        <button data-filter=".filter5" id="taxconsulting"><?= get_sub_field('project_top_content')['project_sub_heading_five'] ?></button>
                                    </div>                    
                                
                                         <div class="row grid" >
                                         <?php  foreach (get_sub_field('project_bottom_content')['content_repeater'] as  $value) { 
                                                     if($value['select_category']=='all'){   ?>
                                                    <div class="col-lg-4 col-md-6 mb-30 grid-item *">
                                                        <div class="project-item">
                                                            <div class="project-img">
                                                                <img src="<?= $value['image']['url'] ?>" alt="images">
                                                            </div>
                                                            <div class="project-content"> 
                                                                <div class="project-inner">
                                                                    <span class="category"><a href="project-single.html"><?= $value['heading'] ?></a></span>
                                                                    <h3 class="title"><a href="project-single.html"><?= $value['sub_heading'] ?></a></h3>
                                                                    <a class="p-icon" href="project-single.html"><?= $value['icon'] ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php  } }?>
                                        
                                         <?php  foreach (get_sub_field('project_bottom_content')['content_repeater'] as  $value) { 
                                                     if($value['select_category']=='businessstrategy'){   ?>
                                                    <div class="col-lg-4 col-md-6 mb-30 grid-item filter2 filter3">
                                                        <div class="project-item">
                                                            <div class="project-img">
                                                                <img src="<?= $value['image']['url'] ?>" alt="images">
                                                            </div>
                                                            <div class="project-content"> 
                                                                <div class="project-inner">
                                                                    <span class="category"><a href="project-single.html"><?= $value['heading'] ?></a></span>
                                                                    <h3 class="title"><a href="project-single.html"><?= $value['sub_heading'] ?></a></h3>
                                                                    <a class="p-icon" href="project-single.html"><?= $value['icon'] ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php  } }?>
                                         
                                         <?php  foreach (get_sub_field('project_bottom_content')['content_repeater'] as  $value) { 
                                                     if($value['select_category']=='financial'){   ?>
                                                    <div class="col-lg-4 col-md-6 mb-30 grid-item filter3 filter 2">
                                                        <div class="project-item">
                                                            <div class="project-img">
                                                                <img src="<?= $value['image']['url'] ?>" alt="images">
                                                            </div>
                                                            <div class="project-content"> 
                                                                <div class="project-inner">
                                                                    <span class="category"><a href="project-single.html"><?= $value['heading'] ?></a></span>
                                                                    <h3 class="title"><a href="project-single.html"><?= $value['sub_heading'] ?></a></h3>
                                                                    <a class="p-icon" href="project-single.html"><?= $value['icon'] ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php  } }?>
                                         
                                         <?php  foreach (get_sub_field('project_bottom_content')['content_repeater'] as  $value) { 
                                                     if($value['select_category']=='investment'){   ?>
                                                    <div class="col-lg-4 col-md-6 mb-30 grid-item filter4 filter 3">
                                                        <div class="project-item">
                                                            <div class="project-img">
                                                                <img src="<?= $value['image']['url'] ?>" alt="images">
                                                            </div>
                                                            <div class="project-content"> 
                                                                <div class="project-inner">
                                                                    <span class="category"><a href="project-single.html"><?= $value['heading'] ?></a></span>
                                                                    <h3 class="title"><a href="project-single.html"><?= $value['sub_heading'] ?></a></h3>
                                                                    <a class="p-icon" href="project-single.html"><?= $value['icon'] ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php  } }?>
                                        
                                         <?php  foreach (get_sub_field('project_bottom_content')['content_repeater'] as  $value) { 
                                                     if($value['select_category']=='taxconsulting'){   ?>
                                                    <div class="col-lg-4 col-md-6 mb-30 grid-item filter5 filter 2">
                                                        <div class="project-item">
                                                            <div class="project-img">
                                                                <img src="<?= $value['image']['url'] ?>" alt="images">
                                                            </div>
                                                            <div class="project-content"> 
                                                                <div class="project-inner">
                                                                    <span class="category"><a href="project-single.html"><?= $value['heading'] ?></a></span>
                                                                    <h3 class="title"><a href="project-single.html"><?= $value['sub_heading'] ?></a></h3>
                                                                    <a class="p-icon" href="project-single.html"><?= $value['icon'] ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php  } }?>
                                         </div>

                         </div>
                </div>
            <!-- Project Section End -->  